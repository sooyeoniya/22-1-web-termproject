<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>🌸</title>
<link rel="stylesheet" type="text/css" href="./css/common.css?after">
<link rel="stylesheet" type="text/css" href="./css/board.css?after">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Do+Hyeon&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<script type="text/javascript" src="./js/like.js" defer></script>
<script type="text/javascript" src="./js/date.js" defer></script>
</head>
<body> 
<header>
    <?php include "header.php";?>
</header>
<section>
	<div id="main_date_bar">
        <body onload="printClock()"><div id="clock"></div></body>
    </div>
   	<div id="board_box">
   		<div class="board_box_header">
   			<h3>
	    	게시판 > 목록보기
			</h3>
			<div class="search_header">
				<form action="search.php" method="get" style="float: right; ">
					<input type="text" name="search" size="30" required="required">&nbsp;
					<button class="w-btn-outline w-btn-gray-outline">검색</button>
				</form>
			</div>
   		</div>
	    <ul id="board_list">
				<li>
					<span class="col1">번호</span>
					<span class="col2">제목</span>
					<span class="col3">글쓴이</span>
					<span class="col4">첨부</span>
					<span class="col5">등록일</span>
					<span class="col6">조회</span>
					<span class="col7">좋아요</span>
				</li>
<?php
	if (isset($_GET["page"]))
		$page = $_GET["page"];
	else
		$page = 1;

	$con = mysqli_connect("localhost", "root", "", "termproject");
	$search_con = $_GET['search']; //검색한 글을 GET 방식으로 받아오기
	$sql2 = "select * from board where subject like '%$search_con%' order by num desc"; // 검색어 찾기
	$result2 = mysqli_query($con, $sql2);
	$total_search = mysqli_num_rows($result2); //검색한 글의 수
	//echo $total_search; // 디버그용 출력
	$scale = 10;
	// 전체 페이지 수($total_page) 계산 
	if ($total_search % $scale == 0)     
		$total_page = floor($total_search/$scale);      
	else
		$total_page = floor($total_search/$scale) + 1; 
 
	// 표시할 페이지($page)에 따라 $start 계산  
	$start = ($page - 1) * $scale;      
	$number = $total_search - $start;

   for ($i=$start; $i<$start+$scale && $i < $total_search; $i++)
   {
      mysqli_data_seek($result2, $i);
      // 가져올 레코드로 위치(포인터) 이동
      $row_search = mysqli_fetch_array($result2); //검색한 문자열 가져오기
      // 하나의 레코드 가져오기
	  $num         = $row_search["num"];
	  $id          = $row_search["id"];
	  $name        = $row_search["name"];
	  $subject     = $row_search["subject"];
      $regist_day  = $row_search["regist_day"];
      $hit         = $row_search["hit"];
      $like_count  = $row_search["like_count"]; // 좋아요

      if ($row_search["file_name"])
      	$file_image = "<img src='./img/file.gif'>";
      else
      	$file_image = " ";
?>
				<li>
					<span class="col1"><?=$number?></span>
					<span class="col2"><a href="board_view.php?num=<?=$num?>&page=<?=$page?>"><?=$subject?></a></span>
					<span class="col3"><?=$name?></span>
					<span class="col4"><?=$file_image?></span>
					<span class="col5"><?=$regist_day?></span>
					<span class="col6"><?=$hit?></span>
					<!--좋아요-->
					<span class="col7">
						<button type="button" class="btn-like" data-board-num="<?=$num?>" data-liked-id="<?=$id?>">
							<span class="heart-shape">🤍</span>
							<span class="like-count"><?=$like_count?></span>
						</button>
					</span>
				</li>
<?php
   	   $number--;
   }
   mysqli_close($con);

?>
	    	</ul>
			<ul id="page_num"> 	
<?php
	if ($total_page>=2 && $page >= 2)	
	{
		$new_page = $page-1;
		echo "<li><a href='board_list.php?page=$new_page'>◀ 이전</a> </li>";
	}		
	else 
		echo "<li>&nbsp;</li>";

   	// 게시판 목록 하단에 페이지 링크 번호 출력
   	for ($i=1; $i<=$total_page; $i++)
   	{
		if ($page == $i)     // 현재 페이지 번호 링크 안함
		{
			echo "<li><b> $i </b></li>";
		}
		else
		{
			echo "<li><a href='board_list.php?page=$i'> $i </a><li>";
		}
   	}
   	if ($total_page>=2 && $page != $total_page)		
   	{
		$new_page = $page+1;	
		echo "<li> <a href='board_list.php?page=$new_page'>다음 ▶</a> </li>";
	}
	else 
		echo "<li>&nbsp;</li>";
?>
			</ul> <!-- page -->

			<ul class="buttons">
				<li><button class="w-btn-outline w-btn-gray-outline" onclick="location.href='board_list.php'">목록</button></li>
				<li>
<?php 
    if($userid) {
?>
					<button class="w-btn-outline w-btn-gray-outline" onclick="location.href='board_form.php'">글쓰기</button>
<?php
	} else {
?>
					<a href="javascript:alert('로그인 후 이용해 주세요!')"><button class="w-btn-outline w-btn-gray-outline" >글쓰기</button></a>
<?php
	}
?>
				</li>
			</ul>
	</div> <!-- board_box -->
</section> 
<footer>
    <?php include "footer.php";?>
</footer>
</body>
</html>
