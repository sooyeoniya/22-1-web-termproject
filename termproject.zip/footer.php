        <div id="footer_content">
            <p id="footer_logo">웹프로그래밍 Term Project <span>최수연</span></p>
            <ul id="download">
                <li>최수연</li>
                <li>- 컴퓨터공학부</li>
                <li>- 2020136129</li>
            </ul>
            <ul id="author">
                <li>저자 문의 메일</li>
                <li>- 메일 주소 : tndus502@koreatech.ac.kr</li>
            </ul>
        </div>